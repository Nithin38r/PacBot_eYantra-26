#!/usr/bin/env python3
"""
"""

import json
import time

import paho.mqtt.client as mqtt

MAZE_ROWS = 13
MAZE_COLS = 13
MQTT_BROKER = "localhost" 
MQTT_PORT = 1883
POSE_TOPIC = "robot/pose"

# wall bit per side, OR'd together
WALL_N, WALL_E, WALL_S, WALL_W = 0x1, 0x2, 0x4, 0x8

WALLS = [
    [12, 6, 12, 6, 13, 4, 0, 4, 5, 6, 12, 5, 6],
    [10, 11, 10, 10, 12, 3, 8, 2, 12, 1, 1, 6, 10],
    [8, 5, 3, 8, 1, 6, 9, 2, 9, 6, 13, 2, 10],
    [10, 12, 4, 3, 12, 1, 4, 0, 6, 9, 4, 2, 10],
    [10, 10, 8, 5, 3, 13, 2, 10, 9, 6, 10, 11, 10],
    [8, 3, 9, 4, 5, 6, 8, 1, 6, 10, 9, 5, 2],
    [10, 12, 4, 1, 6, 10, 9, 6, 10, 8, 5, 5, 2],
    [8, 1, 2, 12, 3, 10, 12, 3, 9, 2, 12, 6, 10],
    [9, 6, 10, 10, 12, 1, 2, 12, 5, 1, 0, 1, 3],
    [14, 8, 1, 1, 3, 12, 1, 3, 12, 4, 2, 12, 6],
    [8, 0, 4, 7, 12, 3, 12, 6, 10, 9, 1, 2, 10],
    [10, 10, 9, 6, 10, 12, 2, 8, 1, 7, 12, 0, 2],
    [9, 1, 5, 1, 1, 3, 8, 1, 5, 5, 3, 9, 3],
]

# the 2 known exits: (row, col, facing)
EXIT_CELLS = [
    (0, 6, 'south'),
    (MAZE_ROWS - 1, 6, 'north'),
]

BOT_CMD_TOPIC = "bot/cmd"         
PELLETS_TOPIC = "pellets/pose"    
CMD_VEL_TOPIC = "robot/cmd_vel"  

# yaw -> dr, dc, wall bit. 0=EAST, 90=NORTH, 180=WEST, 270=SOUTH
HEADING_DELTA = {
    0.0:   (0, 1, WALL_E),
    90.0:  (1, 0, WALL_N),
    180.0: (0, -1, WALL_W),
    270.0: (-1, 0, WALL_S),
}


# ============================================================================
# YOUR ALGORITHM GOES HERE. Everything above and below is plumbing.
# ============================================================================
def choose_command(pacbot_cell, pacbot_yaw, pellets_remaining):
    from collections import deque

    col, row = pacbot_cell

    directions = [
        (0, 1, WALL_E),     # 0 = EAST
        (1, 0, WALL_N),     # 1 = NORTH
        (0, -1, WALL_W),    # 2 = WEST
        (-1, 0, WALL_S)     # 3 = SOUTH
    ]

    heading = {
        0.0: 0,
        90.0: 1,
        180.0: 2,
        270.0: 3
    }

    current_dir = heading[pacbot_yaw]

    def can_move(c, r, direction):
        if not (0 <= c < MAZE_COLS and 0 <= r < MAZE_ROWS):
            return False

        wall = WALLS[c][r]

        if wall & directions[direction][2]:
            return False

        return True

    def find_path(start, goal):
        queue = deque([start])
        parent = {start: None}
        move_used = {}

        while queue:
            current = queue.popleft()

            if current == goal:
                break

            c, r = current

            for d in range(4):
                dc, dr, wall_bit = directions[d]

                if not can_move(c, r, d):
                    continue

                nc = c + dc
                nr = r + dr
                nxt = (nc, nr)

                if nxt not in parent:
                    parent[nxt] = current
                    move_used[nxt] = d
                    queue.append(nxt)

        if goal not in parent:
            return None

        path = []
        node = goal

        while parent[node] is not None:
            path.append(move_used[node])
            node = parent[node]

        path.reverse()
        return path

    # --------------------------------------------------
    # If already at an exit, face the exit and move out
    # --------------------------------------------------

    if pacbot_cell == (0, 6):
        # Top exit: SOUTH
        exit_dir = 3

        turn = (exit_dir - current_dir) % 4

        if turn == 0:
            return "FRONT"
        elif turn == 1:
            return "RIGHT"
        elif turn == 2:
            return "BACK"
        else:
            return "LEFT"

    if pacbot_cell == (MAZE_ROWS - 1, 6):
        # Bottom exit: NORTH
        exit_dir = 1

        turn = (exit_dir - current_dir) % 4

        if turn == 0:
            return "FRONT"
        elif turn == 1:
            return "RIGHT"
        elif turn == 2:
            return "BACK"
        else:
            return "LEFT"

    # --------------------------------------------------
    # Choose targets
    # --------------------------------------------------

    if pellets_remaining:
        targets = list(pellets_remaining)
    else:
        targets = [
            (0, 6),
            (MAZE_ROWS - 1, 6)
        ]

    # --------------------------------------------------
    # Find shortest path to nearest target
    # --------------------------------------------------

    best_path = None

    for target in targets:
        path = find_path(pacbot_cell, target)

        if path is not None:
            if best_path is None or len(path) < len(best_path):
                best_path = path

    # --------------------------------------------------
    # No path found
    # --------------------------------------------------

    if best_path is None:
        return "RIGHT"

    # Already at target
    if len(best_path) == 0:
        return "FRONT"

    # --------------------------------------------------
    # Execute first movement in path
    # --------------------------------------------------

    next_dir = best_path[0]

    turn = (next_dir - current_dir) % 4

    if turn == 0:
        return "FRONT"

    elif turn == 1:
        return "RIGHT"

    elif turn == 2:
        return "BACK"

    else:
        return "LEFT"
# ============================================================================


def parse_pellets(payload):
    return {tuple(cell) for cell in json.loads(payload)}


def main():
    state = {
        "running": False,
        "pellets": set(),
        "cell": (MAZE_ROWS // 2, MAZE_COLS // 2),
        "yaw": 0.0,
        "in_flight": False,
        "got_pose": False,
        "got_pellets": False,
    }

    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="Controller")

    def decide_and_send():
        if (not state["running"] or state["in_flight"]
                or not state["got_pose"] or not state["got_pellets"]):
            return
        print(f"[debug] pose={state['cell']} yaw={state['yaw']} pellets={state['pellets']}")
        cmd = choose_command(state["cell"], state["yaw"], set(state["pellets"]))
        if cmd is not None:
            state["in_flight"] = True
            client.publish(CMD_VEL_TOPIC, cmd)
            print(f"[controller] {state['cell']} yaw={state['yaw']} -> {cmd}, "
                  f"pellets_left={len(state['pellets'])}")

    def on_message(client, userdata, msg):
        try:
            if msg.topic == BOT_CMD_TOPIC:
                running = msg.payload.decode().startswith("1")
                was_running = state["running"]
                state["running"] = running
                if running and not was_running:
                    decide_and_send()   # kick off the reactive loop on Start
            elif msg.topic == PELLETS_TOPIC:
                state["pellets"] = parse_pellets(msg.payload.decode())
                state["got_pellets"] = True
                decide_and_send()
            elif msg.topic == POSE_TOPIC:
                data = json.loads(msg.payload.decode())
                state["cell"] = (int(data["col"]), int(data["row"]))   # wire is swapped
                state["got_pose"] = True
                state["yaw"] = float(data.get("yaw", 0.0))
                state["in_flight"] = False   # this pose is the ack for our last command
                decide_and_send()   # every pose/command-ack triggers the next step
        except Exception as e:
            print("[controller] mqtt parse error:", e)

    client.on_message = on_message
    client.connect(MQTT_BROKER, MQTT_PORT, 60)
    client.subscribe([(BOT_CMD_TOPIC, 0), (PELLETS_TOPIC, 0), (POSE_TOPIC, 0)])
    client.loop_start()

    print(f"[controller] ready; sending one '{CMD_VEL_TOPIC}' command at a time, "
          f"reacting to '{POSE_TOPIC}'/'{PELLETS_TOPIC}' feedback")

    try:
        while True:
            time.sleep(0.2)  
    except KeyboardInterrupt:
        pass
    finally:
        client.loop_stop()
        client.disconnect()


if __name__ == "__main__":
    main()
