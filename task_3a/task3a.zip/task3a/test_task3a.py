import subprocess
import time
import json
import math
import itertools
from collections import deque
import paho.mqtt.client as mqtt
from maze_3a import Maze

maze = Maze.official()

CELL = 0.22
WHEEL_R = 0.017
HALF_TRACK = 0.039
D_AXLE = 0.033
TICK_RAD = 2.0 * math.pi / 360.0
SPAWN_CELL = (14, 0)
SPAWN_XY = (-0.15, 0.00)
SPAWN_HEADING = 0.0

EXITS = {
    "east": {"cell": (7, 14), "heading": 0, "target_xy": (3.45, (14 - 7) * CELL), "check": lambda x, y: x >= 3.25},
    "north": {"cell": (0, 7), "heading": 1, "target_xy": (7 * CELL, 3.45), "check": lambda x, y: y >= 3.25}
}

HEADING_ANGLES = [0.0, math.pi / 2.0, math.pi, -math.pi / 2.0]
DELTA = ((0, 1), (-1, 0), (0, -1), (1, 0))

# Ghost corridor during the initial 25 seconds
GHOST_PATROL_INITIAL = {
    (7, 7), (8, 7), (8, 6), (7, 6), (7, 5), (7, 4), (7, 3), (7, 2), (7, 1), (7, 0),
    (8, 0), (9, 0), (10, 0), (11, 0), (11, 1), (12, 1), (12, 0), (13, 0), (14, 0)
}

def cell_xy(r, c):
    return (c * CELL, (14 - r) * CELL)

def wrap(a):
    return math.atan2(math.sin(a), math.cos(a))

def bfs(start, goal, forbidden=None):
    if forbidden is None:
        forbidden = set()
    if start == goal:
        return [start]
    prev = {start: None}
    q = deque([start])
    while q:
        cur = q.popleft()
        if cur == goal:
            break
        for h, nb in maze.neighbours(cur):
            if nb not in prev and nb not in forbidden:
                prev[nb] = cur
                q.append(nb)
    if goal not in prev:
        return None
    path = []
    c = goal
    while c is not None:
        path.append(c)
        c = prev[c]
    return path[::-1]

def step_heading(c1, c2):
    dr, dc = c2[0] - c1[0], c2[1] - c1[1]
    for h, d in enumerate(DELTA):
        if d == (dr, dc):
            return h
    raise ValueError(f"Non-adjacent: {c1} -> {c2}")

def plan_safe_route(start_cell, remaining_pellets):
    # Try with GHOST_PATROL_INITIAL forbidden (except start and pellet goals)
    forbidden_sets = [
        GHOST_PATROL_INITIAL,
        {(7, 7), (8, 7), (7, 6), (7, 5), (7, 4), (7, 3), (7, 2), (7, 1), (7, 0)},
        {(7, 7)},
        set()
    ]

    best_candidate = None
    for f_base in forbidden_sets:
        for exit_name, exit_info in EXITS.items():
            exit_cell = exit_info["cell"]
            perms = list(itertools.permutations(remaining_pellets)) if remaining_pellets else [[]]
            for perm in perms:
                stops = [start_cell] + list(perm) + [exit_cell]
                path = [start_cell]
                ok = True
                for a, b in zip(stops, stops[1:]):
                    # b and a are allowed
                    f_leg = f_base - {a, b}
                    seg = bfs(a, b, f_leg)
                    if seg is None:
                        ok = False
                        break
                    path.extend(seg[1:])
                if not ok:
                    continue

                turns = 0
                curr_h = 0
                for i in range(1, len(path)):
                    h = step_heading(path[i - 1], path[i])
                    if h != curr_h:
                        turns += 1
                        curr_h = h

                cost = len(path) + turns * 1.5
                if best_candidate is None or cost < best_candidate[0]:
                    best_candidate = (cost, path, list(perm), exit_name)

        if best_candidate is not None:
            break

    if best_candidate is None:
        return None, None, None

    cost, full_path, order, exit_name = best_candidate
    print(f"Safe route: order={order}, exit={exit_name}, cells={len(full_path)}")
    exit_info = EXITS[exit_name]
    moves = []
    for i in range(1, len(full_path)):
        c_from = full_path[i - 1]
        c_to = full_path[i]
        h = step_heading(c_from, c_to)
        moves.append({
            "from": c_from,
            "to": c_to,
            "heading": h,
            "target_angle": HEADING_ANGLES[h],
            "target_xy": cell_xy(*c_to),
        })

    moves.append({
        "from": exit_info["cell"],
        "to": exit_info["cell"],
        "heading": exit_info["heading"],
        "target_angle": HEADING_ANGLES[exit_info["heading"]],
        "target_xy": exit_info["target_xy"],
        "is_exit": True,
        "exit_check": exit_info["check"]
    })

    return moves, order, exit_name

class State:
    def __init__(self):
        self.pellets = None
        self.ghost = None
        self.last_ticks = None
        self.xa = SPAWN_XY[0] - D_AXLE
        self.ya = SPAWN_XY[1]
        self.th = SPAWN_HEADING
        self.total_dist = 0.0
        self.moves = []
        self.move_idx = 0
        self.mode = "DRIVE"
        self.finished = False
        self.pause_frames = 0
        self.curr_cell = SPAWN_CELL
        self.spawn_entered = False
        self.exit_name = None

    @property
    def xc(self):
        return self.xa + D_AXLE * math.cos(self.th)

    @property
    def yc(self):
        return self.ya + D_AXLE * math.sin(self.th)

S = State()

def on_sensors(client, d):
    dt = d.get("dt", 0.01)
    tl, tr = d["ticks_l"], d["ticks_r"]
    if S.last_ticks is None:
        S.last_ticks = (tl, tr)
        return
    dl, dr = tl - S.last_ticks[0], tr - S.last_ticks[1]
    S.last_ticks = (tl, tr)
    dist = WHEEL_R * ((dl + dr) / 2.0) * TICK_RAD
    S.total_dist += dist
    wz = d["gyro"][2]
    S.th = wrap(S.th + wz * dt)
    S.xa += dist * math.cos(S.th)
    S.ya += dist * math.sin(S.th)

    if S.pellets is None:
        return

    # Entry into (14, 0)
    if not S.spawn_entered:
        dist_rem = 0.00 - S.xa
        if dist_rem <= 0.005:
            S.spawn_entered = True
            S.curr_cell = (14, 0)
            S.xa = 0.0
            S.ya = 0.0
            S.moves, order, S.exit_name = plan_safe_route(S.curr_cell, S.pellets)
            S.move_idx = 0
            if S.moves[0]["heading"] != 0:
                S.mode = "TURN"
            else:
                S.mode = "DRIVE"
            client.publish("pacbot/wheel_vel", json.dumps({"left": 0.0, "right": 0.0}))
            return
        else:
            client.publish("pacbot/wheel_vel", json.dumps({"left": 13.0, "right": 13.0}))
            return

    if S.finished or S.move_idx >= len(S.moves):
        client.publish("pacbot/wheel_vel", json.dumps({"left": 0.0, "right": 0.0}))
        return

    if S.pause_frames > 0:
        S.pause_frames -= 1
        client.publish("pacbot/wheel_vel", json.dumps({"left": 0.0, "right": 0.0}))
        return

    cur_move = S.moves[S.move_idx]
    h = cur_move["heading"]
    target_th = cur_move["target_angle"]
    is_exit = cur_move.get("is_exit", False)

    # State: TURN
    if S.mode == "TURN":
        err = wrap(target_th - S.th)
        if abs(err) < 0.035 and abs(wz) < 0.35:
            S.mode = "DRIVE"
            S.pause_frames = 2
            client.publish("pacbot/wheel_vel", json.dumps({"left": 0.0, "right": 0.0}))
            return
        w = max(-8.0, min(8.0, 6.0 * err - 1.0 * wz))
        if abs(w) < 2.2:
            w = math.copysign(2.2, w)
        client.publish("pacbot/wheel_vel", json.dumps({"left": round(-w, 3), "right": round(w, 3)}))
        return

    # State: DRIVE
    if S.mode == "DRIVE":
        if is_exit:
            if cur_move["exit_check"](S.xc, S.yc):
                S.finished = True
                client.publish("pacbot/wheel_vel", json.dumps({"left": 0.0, "right": 0.0}))
                return
            client.publish("pacbot/wheel_vel", json.dumps({"left": 14.0, "right": 14.0}))
            return

        c_to = cur_move["to"]
        cx, cy = cur_move["target_xy"]
        has_front_wall = not maze.can_move(c_to, h)
        is_last_in_corridor = (S.move_idx + 1 < len(S.moves) and S.moves[S.move_idx + 1]["heading"] != h)

        tgt_xa, tgt_ya = cx, cy
        if h == 0:
            dist_rem = tgt_xa - S.xa
            d_lat = tgt_ya - S.ya
        elif h == 1:
            dist_rem = tgt_ya - S.ya
            d_lat = S.xa - tgt_xa
        elif h == 2:
            dist_rem = S.xa - tgt_xa
            d_lat = S.ya - tgt_ya
        else:
            dist_rem = S.ya - tgt_ya
            d_lat = tgt_xa - S.xa

        fl, fr = d["fl"], d["fr"]
        front = min(d["sl"], d["sr"])

        # Lateral ToF centering
        has_l = fl < 0.16
        has_r = fr < 0.16
        if has_l and has_r:
            d_tof = (fl - fr) / 2.0
            d_lat = 0.3 * d_lat + 0.7 * d_tof
        elif has_l:
            d_tof = fl - 0.100
            d_lat = 0.3 * d_lat + 0.7 * d_tof
        elif has_r:
            d_tof = 0.100 - fr
            d_lat = 0.3 * d_lat + 0.7 * d_tof

        need_turn = is_last_in_corridor or has_front_wall

        if need_turn:
            arrived = dist_rem <= 0.005
            front_stop = has_front_wall and (front <= 0.088)
            if arrived or front_stop:
                S.xa, S.ya = tgt_xa, tgt_ya
                S.curr_cell = c_to
                S.move_idx += 1
                if S.move_idx >= len(S.moves):
                    S.finished = True
                else:
                    if S.moves[S.move_idx]["heading"] != h:
                        S.mode = "TURN"
                        S.pause_frames = 2
                    else:
                        S.mode = "DRIVE"
                client.publish("pacbot/wheel_vel", json.dumps({"left": 0.0, "right": 0.0}))
                return
        else:
            if dist_rem <= 0.005:
                S.curr_cell = c_to
                S.move_idx += 1
                return

        th_corr = max(-0.22, min(0.22, 4.0 * d_lat))
        head_err = wrap(target_th + th_corr - S.th)

        slow_down = (need_turn and dist_rem < 0.08) or (has_front_wall and front < 0.20)
        speed = 5.0 if slow_down else 13.5

        max_corr = 0.18 * speed
        corr = max(-max_corr, min(max_corr, 4.5 * head_err))

        left = speed - corr
        right = speed + corr

        client.publish("pacbot/wheel_vel", json.dumps({"left": round(left, 3), "right": round(right, 3)}))

def run_single():
    global S
    S = State()
    sim = subprocess.Popen(["./task_3a_launch"], cwd="/home/mohan/pacbot_ws/task3a", stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    time.sleep(0.8)
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)

    def on_msg(c, u, m):
        try:
            payload = json.loads(m.payload.decode())
        except:
            return
        if m.topic == "pacbot/pellets":
            new_pellets = [tuple(p) for p in payload.get("pellets", [])]
            if S.pellets is not None and len(new_pellets) < len(S.pellets):
                print(f"[{time.time():.2f}] PELLET COLLECTED! Remaining: {new_pellets}")
            S.pellets = new_pellets
        elif m.topic == "pacbot/ghost":
            S.ghost = payload
        elif m.topic == "pacbot/sensors":
            on_sensors(c, payload)
        elif m.topic == "pacbot/result":
            print("SIM RESULT:", payload)
            S.finished = True
            c.disconnect()

    client.on_message = on_msg
    client.connect("localhost", 1883)
    client.subscribe("pacbot/#")

    t0 = time.time()
    while time.time() - t0 < 80.0 and not S.finished:
        client.loop(timeout=0.05)

    sim.terminate()
    out, err = sim.communicate()
    print("=== SIM OUTPUT ===")
    print(out.decode())

if __name__ == "__main__":
    run_single()
