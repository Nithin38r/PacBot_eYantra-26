import subprocess
import time
import json
import math
import itertools
from collections import deque
import paho.mqtt.client as mqtt
import maze_2b

maze = maze_2b.Maze.official()

CELL = 0.22
WHEEL_R = 0.017
D_AXLE = 0.033
TICK_RAD = 2.0 * math.pi / 360.0
SPAWN_CELL = (14, 0)
SPAWN_XY = (-0.15, 0.00)
SPAWN_HEADING = 0.0
EXIT_ROW = 7
EXIT_XY = (3.45, (14 - EXIT_ROW) * CELL)

HEADING_ANGLES = [0.0, math.pi / 2.0, math.pi, -math.pi / 2.0]
DELTA = ((0, 1), (-1, 0), (0, -1), (1, 0))

def cell_xy(r, c):
    return (c * CELL, (14 - r) * CELL)

def wrap(a):
    return math.atan2(math.sin(a), math.cos(a))

def bfs(start, goal):
    if start == goal:
        return [start]
    prev = {start: None}
    q = deque([start])
    while q:
        cur = q.popleft()
        if cur == goal:
            break
        for h, nb in maze.neighbours(cur):
            if nb not in prev:
                prev[nb] = cur
                q.append(nb)
    if goal not in prev:
        return None
    path = []
    c = goal
    while c is not None:
        path.append(c)
        c = prev[c]
    return path[::-1]

def best_order(pellets):
    exit_cell = (EXIT_ROW, 14)
    best = None
    for perm in itertools.permutations(pellets):
        stops = [SPAWN_CELL] + list(perm) + [exit_cell]
        total, full, ok = 0, [SPAWN_CELL], True
        for a, b in zip(stops, stops[1:]):
            seg = bfs(a, b)
            if seg is None:
                ok = False
                break
            total += len(seg) - 1
            full.extend(seg[1:])
        if ok and (best is None or total < best[0]):
            best = (total, full, list(perm))
    return best

def step_heading(c1, c2):
    dr, dc = c2[0] - c1[0], c2[1] - c1[1]
    for h, d in enumerate(DELTA):
        if d == (dr, dc):
            return h
    raise ValueError(f"Non-adjacent: {c1} -> {c2}")

def plan_path(pellets):
    total, full_path, order = best_order(pellets)
    moves = []
    for i in range(1, len(full_path)):
        c_from = full_path[i - 1]
        c_to = full_path[i]
        h = step_heading(c_from, c_to)
        moves.append({
            "from": c_from,
            "to": c_to,
            "heading": h,
            "target_angle": HEADING_ANGLES[h],
            "target_xy": cell_xy(*c_to),
        })

    if moves[0]["heading"] != 0:
        moves.insert(0, {
            "from": (14, -1),
            "to": (14, 0),
            "heading": 0,
            "target_angle": 0.0,
            "target_xy": cell_xy(14, 0),
        })

    moves.append({
        "from": (EXIT_ROW, 14),
        "to": (EXIT_ROW, 15),
        "heading": 0,
        "target_angle": 0.0,
        "target_xy": EXIT_XY,
        "is_exit": True
    })
    return moves, order

class State:
    def __init__(self):
        self.pellets = None
        self.ghost = None
        self.last_ticks = None
        self.xa = SPAWN_XY[0] - D_AXLE
        self.ya = SPAWN_XY[1]
        self.th = SPAWN_HEADING
        self.total_dist = 0.0
        self.start_sim = time.time()
        self.planned = False
        self.moves = []
        self.move_idx = 0
        self.mode = "WAIT_PELLETS" # WAIT_PELLETS, TURN, DRIVE, FINISHED
        self.finished = False
        self.pause_frames = 0
        self.pellets_received_time = None

    @property
    def xc(self):
        return self.xa + D_AXLE * math.cos(self.th)

    @property
    def yc(self):
        return self.ya + D_AXLE * math.sin(self.th)

S = State()

def ghost_blocks():
    if S.ghost is None:
        return False
    gx, gy = S.ghost["x"], S.ghost["y"]
    d_bot = math.hypot(gx - S.xc, gy - S.yc)
    if d_bot < 0.35:
        return True
    gr, gc = S.ghost["row"], S.ghost["col"]
    br = min(max(int(round((14 * CELL - S.yc) / CELL)), 0), 14)
    bc = min(max(int(round(S.xc / CELL)), 0), 14)
    if (gr, gc) == (br, bc) and d_bot < 0.42:
        return True
    for offset in (0, 1, 2):
        idx = S.move_idx + offset
        if idx < len(S.moves):
            if (gr, gc) == S.moves[idx]["to"] and d_bot < 0.42:
                return True
    return False

def on_sensors(client, d):
    dt = d.get("dt", 0.01)
    tl, tr = d["ticks_l"], d["ticks_r"]
    if S.last_ticks is None:
        S.last_ticks = (tl, tr)
        return
    dl, dr = tl - S.last_ticks[0], tr - S.last_ticks[1]
    S.last_ticks = (tl, tr)
    dist = WHEEL_R * ((dl + dr) / 2.0) * TICK_RAD
    S.total_dist += dist
    wz = d["gyro"][2]
    S.th = wrap(S.th + wz * dt)
    S.xa += dist * math.cos(S.th)
    S.ya += dist * math.sin(S.th)
    with open('sim_all.log', 'a') as f_all:
        f_all.write(f"{d.get('t', 0.0):6.3f} m={S.move_idx:2d} mode={S.mode:12s} blk={ghost_blocks()} pause={S.pause_frames} pos=({S.xa:6.3f},{S.ya:6.3f}) th={math.degrees(S.th):+6.1f} wz={wz:+5.2f}\n")

    if not S.pellets:
        return

    if S.mode == "WAIT_PELLETS":
        if S.pellets_received_time is None:
            S.pellets_received_time = time.time()
        # Brief pause to ensure clean start
        if time.time() - S.pellets_received_time >= 0.5:
            S.moves, order = plan_path(S.pellets)
            print(f"Planned order: {order}, total moves: {len(S.moves)}")
            S.move_idx = 0
            first_h = S.moves[0]["heading"]
            if first_h == 0:
                S.mode = "DRIVE"
            else:
                S.mode = "TURN"
            S.planned = True
        client.publish("pacbot/wheel_vel", json.dumps({"left": 0.0, "right": 0.0}))
        return

    if S.finished or S.move_idx >= len(S.moves):
        client.publish("pacbot/wheel_vel", json.dumps({"left": 0.0, "right": 0.0}))
        return

    if ghost_blocks():
        client.publish("pacbot/wheel_vel", json.dumps({"left": 0.0, "right": 0.0}))
        return

    if S.pause_frames > 0:
        S.pause_frames -= 1
        client.publish("pacbot/wheel_vel", json.dumps({"left": 0.0, "right": 0.0}))
        return

    cur_move = S.moves[S.move_idx]
    h = cur_move["heading"]
    target_th = cur_move["target_angle"]
    is_exit = cur_move.get("is_exit", False)

    # State: TURN
    if S.mode == "TURN":
        err = wrap(target_th - S.th)
        if abs(err) < 0.035 and abs(wz) < 0.35:
            S.mode = "DRIVE"
            S.pause_frames = 2
            client.publish("pacbot/wheel_vel", json.dumps({"left": 0.0, "right": 0.0}))
            return
        w = max(-7.5, min(7.5, 6.0 * err - 1.0 * wz))
        if abs(w) < 2.2:
            w = math.copysign(2.2, w)
        client.publish("pacbot/wheel_vel", json.dumps({"left": round(-w, 3), "right": round(w, 3)}))
        return

    # State: DRIVE
    if S.mode == "DRIVE":
        if is_exit:
            if S.xc >= 3.25:
                S.finished = True
                client.publish("pacbot/wheel_vel", json.dumps({"left": 0.0, "right": 0.0}))
                return
            client.publish("pacbot/wheel_vel", json.dumps({"left": 14.0, "right": 14.0}))
            return

        c_to = cur_move["to"]
        cx, cy = cur_move["target_xy"]
        has_front_wall = not maze.can_move(c_to, h)
        is_last_in_corridor = (S.move_idx + 1 < len(S.moves) and S.moves[S.move_idx + 1]["heading"] != h)

        # Axle targets cell center directly: rotation occurs around axle,
        # so keeping axle at cell center ensures zero lateral offset in both incoming and outgoing corridors
        tgt_xa, tgt_ya = cx, cy
        if h == 0:
            dist_rem = tgt_xa - S.xa
            d_lat = tgt_ya - S.ya
        elif h == 1:
            dist_rem = tgt_ya - S.ya
            d_lat = S.xa - tgt_xa
        elif h == 2:
            dist_rem = S.xa - tgt_xa
            d_lat = S.ya - tgt_ya
        else:
            dist_rem = S.ya - tgt_ya
            d_lat = tgt_xa - S.xa

        fl, fr = d["fl"], d["fr"]
        front = min(d["sl"], d["sr"])

        has_l = fl < 0.16
        has_r = fr < 0.16
        if has_l and has_r:
            d_tof = (fl - fr) / 2.0
            d_lat = 0.3 * d_lat + 0.7 * d_tof
        elif has_l:
            d_tof = fl - 0.100
            d_lat = 0.3 * d_lat + 0.7 * d_tof
        elif has_r:
            d_tof = 0.100 - fr
            d_lat = 0.3 * d_lat + 0.7 * d_tof

        need_turn = is_last_in_corridor or has_front_wall

        # Arrival detection
        if need_turn:
            # When stopping for a turn, stop with plenty of front clearance (front >= 0.115 at cell center)
            arrived = dist_rem <= 0.005
            front_stop = has_front_wall and (front <= 0.088)
            if arrived or front_stop:
                S.xa, S.ya = tgt_xa, tgt_ya
                S.move_idx += 1
                if S.move_idx >= len(S.moves):
                    S.finished = True
                else:
                    S.mode = "TURN"
                    S.pause_frames = 2
                client.publish("pacbot/wheel_vel", json.dumps({"left": 0.0, "right": 0.0}))
                return
        else:
            # Continuing straight: transition to next cell move once past boundary
            if dist_rem <= 0.005:
                S.move_idx += 1
                return

        th_corr = max(-0.22, min(0.22, 4.0 * d_lat))
        head_err = wrap(target_th + th_corr - S.th)

        slow_down = (need_turn and dist_rem < 0.08) or (has_front_wall and front < 0.20)
        speed = 5.0 if slow_down else 13.0

        max_corr = 0.18 * speed
        corr = max(-max_corr, min(max_corr, 4.5 * head_err))

        left = speed - corr
        right = speed + corr
        
        with open('sim_frames.log', 'a') as f_log:
            f_log.write(f"{d['t']:6.3f} m={S.move_idx:2d} mode={S.mode:5s} pos=({S.xa:6.3f},{S.ya:6.3f}) th={math.degrees(S.th):+6.1f} rem={dist_rem:6.3f} fl={fl:5.3f} fr={fr:5.3f} front={front:5.3f} spd={speed:4.1f} L={left:5.2f} R={right:5.2f}\n")
        client.publish("pacbot/wheel_vel", json.dumps({"left": round(left, 3), "right": round(right, 3)}))

def main():
    sim = subprocess.Popen(["./task_2b_launch"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    time.sleep(1.0)
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)

    def on_msg(c, u, m):
        try:
            payload = json.loads(m.payload.decode())
        except:
            return
        if m.topic == "pacbot/pellets":
            S.pellets = [tuple(p) for p in payload.get("pellets", [])]
        elif m.topic == "pacbot/ghost":
            S.ghost = payload
        elif m.topic == "pacbot/sensors":
            on_sensors(c, payload)
        elif m.topic == "pacbot/result":
            print("SIM RESULT:", payload)
            S.finished = True
            c.disconnect()

    client.on_message = on_msg
    client.connect("localhost", 1883)
    client.subscribe("pacbot/#")

    t0 = time.time()
    while time.time() - t0 < 80.0 and not S.finished:
        client.loop(timeout=0.05)

    sim.terminate()
    out, err = sim.communicate()
    print("=== SIMULATOR OUTPUT ===")
    print(out.decode())

if __name__ == "__main__":
    main()
