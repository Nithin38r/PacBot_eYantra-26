"""Boilerplate for PB Task 2B.

All the plumbing, none of the thinking. It connects to the broker, loads the
official maze, receives the pellet positions for this run, and publishes a
wheel velocity command on every sensor frame. Your job is the one TODO block
in `decide()`.

Run it in two terminals, from the folder you unpacked:

    ./task_2b_launch                 # terminal 1: the simulator
    python3 task_2b_boilerplate.py   # terminal 2: this file

Neither takes a maze argument. The official maze is built into both, so there
is no path to get wrong and no way for your planner and the simulator to end
up looking at different walls. If the broker is not already running:

    sudo systemctl enable --now mosquitto

Everything you need is in this file: the maze, where you start and finish, and
every message the simulator will send you. Read on.

------------------------------------------------------------------------------
WHAT YOU ARE GIVEN

The maze. Fixed for the whole Sub-Task and published, so you may read it,
precompute against it, and plan routes offline. `Maze.official()` hands it to
you already parsed, from a copy embedded in maze_2b.py, which is the same text
built into the simulator. This is deliberately
not a mapping task - the ToF sensors are for driving accurately, not for
discovering walls.

The pellets. THREE cells, delivered over `pacbot/pellets` when the run starts,
and different on every single run. You cannot hardcode a route. Every possible
pellet set has been checked to need the same optimal driving time, so no draw
is luckier than another; the only thing that separates two teams is how well
they plan and drive.

------------------------------------------------------------------------------
THE MAZE

This is the whole thing. It never changes, so plan against it offline.
`Maze.official()` returns it already parsed; the drawing below is the same
maze for reading with your eyes.

        col    0   1   2   3   4   5   6   7   8   9  10  11  12  13  14
             +---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+
     row 0   |                           |       |       |               |
             +   +---+---+   +---+   +   +   +   +   +   +   +---+   +---+
     row 1   |   |               |   |       |       |   |       |       |
             +   +   +   +---+   +   +   +   +---+   +   +   +---+---+   +
     row 2   |   |   |       |   |       |       |   |               |   |
             +   +   +   +---+   +   +   +---+   +   +---+   +   +   +   +
     row 3   |       |               |           |           |   |       |
             +---+---+   +---+---+   +   +---+   +---+---+---+   +   +---+
     row 4   |   |               |   |               |                   |
             +   +   +---+   +   +   +---+---+---+   +---+   +   +---+   +
     row 5   |       |       |   |               |           |           |
             +   +---+   +---+   +   +---+---+   +   +---+---+   +---+   +
     row 6   |       |   |       |           |       |           |       |
             +---+   +   +   +---+---+---+   +---+---+   +   +---+   +---+
     row 7   |                           |               |               E
             +   +---+---+   +---+---+   +   +   +---+---+   +   +---+   +
     row 8   |           |                   |               |           |
             +   +   +   +   +---+---+---+   +---+   +   +---+   +---+---+
     row 9   |   |   |       |                   |   |                   |
             +   +   +---+   +   +---+   +---+   +   +---+---+   +---+   +
     row 10  |           |           |           |           |   |       |
             +   +---+   +---+---+   +   +---+---+   +   +   +   +   +   +
     row 11  |       |           |                   |   |   |   |   |   |
             +---+   +   +---+   +---+---+   +---+   +   +   +   +   +   +
     row 12  |       |               |           |       |           |   |
             +   +   +---+   +---+   +   +---+   +---+   +   +---+   +   +
     row 13  |   |           |       |       |               |           |
             +   +   +   +---+   +   +---+   +   +   +---+   +   +---+   +
     row 14  S       |           |                       |               |
             +---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+

You START outside the west border at the `S` gap on row 14, facing EAST, and
drive into cell (14, 0). You FINISH by leaving cell (7, 14) through the `E`
gap in the east border. Crossing that plane is the only thing that ends a run
successfully.

Coordinates. Cells are (row, col), both zero-based, with row 0 at the TOP of
the drawing and col 0 at the LEFT. Headings are

    EAST = 0    NORTH = 1    WEST = 2    SOUTH = 3

The order runs counter-clockwise, so (heading + 1) % 4 is a 90 degree turn to
the LEFT, and (heading + 3) % 4 is a turn to the RIGHT. You spawn facing EAST,
which is heading 0.

Cell centres in metres. This is the frame the ghost's x/y arrive in, and the
one to dead-reckon in:

    x = col * 0.22
    y = (14 - row) * 0.22

So cell (14, 0) sits at (0.00, 0.00) and cell (0, 14) at (3.08, 3.08). Driving
EAST increases x; driving NORTH increases y. Going back the other way:

    col = round(x / 0.22)
    row = 14 - round(y / 0.22)

You spawn at (-0.15, 0.00), in the short chute outside the west border, so
your first move is eastward through the gap. The run ends when your chassis
crosses x = 3.19, which is the east border plane half a pitch beyond the
centres of column 14.

Asking the maze about walls, rather than working it out from the drawing:

    maze.can_move((7, 0), Maze.EAST)     # -> True / False
    maze.grid                            # 15
    maze.pitch                           # 0.22
    maze.spawn_row, maze.exit_row        # 14, 7

------------------------------------------------------------------------------
THE WIRE PROTOCOL

  pacbot/sensors    simulator -> you, 100 times a second
    {"fl": .., "fr": .., "sl": .., "sr": ..,
     "gyro":  [wx, wy, wz], "accel": [ax, ay, az],
     "ticks_l": .., "ticks_r": .., "dt": .., "t": ..}

    The physics runs at 500 Hz; you see every fifth step, so dt is always
    0.010. The simulator does not wait for you between frames - it keeps
    stepping and the wheels hold your last command.

    fl  metres to the wall on the LEFT,  90 deg left of forward  (+y)
    fr  metres to the wall on the RIGHT, 90 deg right of forward (-y)
    sl  metres to the wall AHEAD, 0 deg, from left of centre     (+x)
    sr  metres to the wall AHEAD, 0 deg, from right of centre    (+x)

      All four rays are axis-aligned, so a reading IS the perpendicular
      distance. No trigonometry needed.

      Do not be misled by the names: `fl`/`fr` look sideways and `sl`/`sr`
      look forward. They are inherited from Task 1B so your 1B code still
      works.

      RANGE. The sensors see 2.0 m and no further, like the real hardware.
      A reading of 2.0 means "at least 2 m away, or nothing there at all" -
      you cannot tell those apart, and neither can a real ToF module. Every
      reading is therefore in [0.0, 2.0].

      THE PELLETS ARE INVISIBLE TO THESE SENSORS. They are simulated as
      sites, which the rangefinders cannot see, so you cannot sweep the maze
      looking for them - a ToF ray passes straight through a pellet and
      reports the wall behind it. The only source of pellet positions is the
      pacbot/pellets topic below.

    gyro[2]        yaw rate about z, rad/s. Integrate it to measure turns.
    accel          body-frame acceleration, m/s^2.
    ticks_l,       RUNNING encoder counts, 360 per wheel revolution, positive
    ticks_r        forward. These are cumulative totals, not rates: subtract
                   successive readings to get how far each wheel turned, so a
                   dropped message loses nothing.

                       dl = ticks_l - prev_ticks_l
                       dr = ticks_r - prev_ticks_r
                       distance = WHEEL_RADIUS * ((dl + dr) / 2) * 2*pi/360
    dt             seconds covered by this frame.
    t              simulator clock, seconds since the run started.
  pacbot/pellets    simulator -> you, at startup and after each collection
    {"pellets": [[row, col], [row, col], [row, col]]}

    The pellets STILL on the board. The list shrinks as you collect them, and
    an empty list means all three are yours. Retained, so a late subscriber
    still gets it.

    Wrapped in an object with a named key, like Task 2A's pellet message,
    so the topic can gain more fields later without breaking your parser.

  pacbot/ghost      simulator -> you, every sensor frame
    {"row": .., "col": .., "x": .., "y": ..}

    Where the patrolling ghost is RIGHT NOW: its cell, and its exact position
    in metres. RETAINED, so subscribing late still tells you where it is.

    It never chases you, but touching it ends your run with whatever pellets
    you have already collected. Its route is never published: watch it and
    work the circuit out yourself. It is slower than you are and it is on a
    circuit, so waiting always works.

  pacbot/result     simulator -> you, ONCE, when the run ends
    {"solved": true, "collisions": 0}

    Sent when the maze is solved, or when the window is closed on a run that
    was not solved. It tells you the run is over and roughly how it went.
    "solved" means all three pellets AND out through the exit; exiting with
    two pellets is not solved.

    It deliberately carries no score, no time and no pellet detail. Those are
    in the sealed result.json only. Not retained, so it can never be mistaken
    for the previous run's outcome.

  pacbot/wheel_vel  you -> simulator
    {"left": <rad/s>, "right": <rad/s>}

    Clamped to +-30 rad/s. Publish one per sensor frame.

    The simulator does NOT wait for you. It keeps stepping at the wall clock
    and the wheels hold whatever command arrived last, exactly as a real
    robot coasts on its last instruction between control updates. Miss a
    frame and you simply steer on a slightly older reading; nothing breaks.

    The keys must appear in THIS ORDER: the simulator matches the message
    against a fixed pattern, so {"right": .., "left": ..} is discarded
    without an error. Building the dict as {"left": .., "right": ..} and
    passing it to json.dumps gives the right shape, as the code below does.

------------------------------------------------------------------------------
GEOMETRY YOU WILL NEED

    cell pitch      0.22 m          maze.pitch
    wheel radius    0.017 m
    half track      0.039 m         wheel centre to robot centreline
    grid            15 x 15         maze.grid

A pellet is collected when the chassis centre passes within 0.06 m of the cell
centre, so clipping a corner does not count. The run ends when the chassis
crosses the exit plane on the east border.
"""
import itertools
import json
import math
import time
from collections import deque

import paho.mqtt.client as mqtt

import maze_2b
from maze_2b import Maze

MQTT_HOST = "localhost"
MQTT_PORT = 1883
TOPIC_SENSORS = "pacbot/sensors"      # simulator publishes, this file subscribes
TOPIC_PELLETS = "pacbot/pellets"      # simulator publishes, this file subscribes
TOPIC_GHOST = "pacbot/ghost"          # simulator publishes, this file subscribes
TOPIC_RESULT = "pacbot/result"        # simulator publishes, this file subscribes
TOPIC_WHEEL_VEL = "pacbot/wheel_vel"  # this file publishes, simulator subscribes

WHEEL_RADIUS = 0.017  # m
HALF_TRACK = 0.039    # m, wheel centre to centreline
WHEEL_LIMIT = 30.0    # rad/s, the simulator clamps to this
TICKS_PER_REV = 360   # encoder counts per wheel revolution
TICK_RAD = 2.0 * math.pi / TICKS_PER_REV   # radians of wheel turn per tick
AXLE_OFFSET = 0.033   # m, axle is 0.033 m behind chassis centre
CELL = 0.22           # m, cell pitch
GRID = 15

SPAWN_ROW = 14
SPAWN_XY = (-0.15, 0.00)
SPAWN_HEADING = 0.0   # facing East
EXIT_ROW = 7
EXIT_XY = (3.45, (14 - EXIT_ROW) * CELL)
EAST_BORDER = 3.19


def _mqtt_client():
    # paho-mqtt >= 2.0 requires picking a callback API version explicitly.
    try:
        return mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    except AttributeError:
        return mqtt.Client()


def wheels(forward, turn):
    """Differential drive mixer: +turn steers LEFT (counter-clockwise)."""
    return forward - turn, forward + turn


def wrap(a):
    """Wrap angle to [-pi, pi]."""
    return math.atan2(math.sin(a), math.cos(a))


def cell_xy(r, c):
    """Convert cell (row, col) to world coordinates (x, y) in meters."""
    return (c * CELL, (14 - r) * CELL)


def bfs_path(maze, start_cell, goal_cell):
    """Shortest path between two cells in the official maze."""
    if start_cell == goal_cell:
        return [start_cell]
    q = deque([start_cell])
    parent = {start_cell: None}
    while q:
        curr = q.popleft()
        if curr == goal_cell:
            break
        for h, nxt in maze.neighbours(curr):
            if nxt not in parent:
                parent[nxt] = curr
                q.append(nxt)
    if goal_cell not in parent:
        return None
    path = []
    curr = goal_cell
    while curr is not None:
        path.append(curr)
        curr = parent[curr]
    return path[::-1]


def best_order(maze, pellets):
    """Try all 6 permutations of the 3 pellets; return (total_cells, full_cell_path, order)."""
    exit_cell = (maze.exit_row, maze.grid - 1)
    spawn_cell = maze.spawn_cell
    best = None
    for perm in itertools.permutations(pellets):
        stops = [spawn_cell] + list(perm) + [exit_cell]
        total_cells = 0
        full_path = [spawn_cell]
        ok = True
        for a, b in zip(stops, stops[1:]):
            seg = bfs_path(maze, a, b)
            if seg is None:
                ok = False
                break
            total_cells += len(seg) - 1
            full_path.extend(seg[1:])
        if ok and (best is None or total_cells < best[0]):
            best = (total_cells, full_path, list(perm))
    return best


def path_to_segments(path):
    """Compress consecutive cell moves into straight-line corridor segments."""
    if len(path) < 2:
        return []
    DELTA = ((0, 1), (-1, 0), (0, -1), (1, 0))
    HEADING_ANGLES = [0.0, math.pi / 2.0, math.pi, -math.pi / 2.0]

    def step_heading(c1, c2):
        dr, dc = c2[0] - c1[0], c2[1] - c1[1]
        for h, d in enumerate(DELTA):
            if d == (dr, dc):
                return h
        raise ValueError(f"Non-adjacent cells: {c1} -> {c2}")

    segments = []
    first_h = step_heading(path[0], path[1])
    # If initial path moves North from (14, 0), robot must first drive into (14, 0) Eastward
    if first_h != 0:
        segments.append({
            "heading": 0,
            "target_angle": 0.0,
            "start_cell": (14, 0),
            "end_cell": (14, 0),
            "target_xy": cell_xy(14, 0),
            "is_exit": False,
        })

    curr_h = first_h
    seg_start = path[0]
    for i in range(1, len(path)):
        h = step_heading(path[i - 1], path[i])
        if h != curr_h:
            end_c = path[i - 1]
            segments.append({
                "heading": curr_h,
                "target_angle": HEADING_ANGLES[curr_h],
                "start_cell": seg_start,
                "end_cell": end_c,
                "target_xy": cell_xy(*end_c),
                "is_exit": False,
            })
            curr_h = h
            seg_start = end_c

    end_c = path[-1]
    segments.append({
        "heading": curr_h,
        "target_angle": HEADING_ANGLES[curr_h],
        "start_cell": seg_start,
        "end_cell": end_c,
        "target_xy": cell_xy(*end_c),
        "is_exit": False,
    })

    # Add final exit segment leaving through east border from (7, 14)
    segments.append({
        "heading": 0,
        "target_angle": 0.0,
        "start_cell": end_c,
        "end_cell": (EXIT_ROW, 14),
        "target_xy": EXIT_XY,
        "is_exit": True,
    })

    return segments


class Controller:
    def __init__(self, maze):
        self.maze = maze
        self.pellets = []     # cells still on the board; filled from MQTT
        self.have_pellets = False
        self.elapsed = 0.0
        self.ghost = None     # latest pacbot/ghost payload, or None
        self.prev_ticks = None  # (left, right) counts from the previous frame

        # Dead reckoning odometry
        self.x = SPAWN_XY[0]
        self.y = SPAWN_XY[1]
        self.th = SPAWN_HEADING
        self.total_travel = 0.0

        # Ghost observation
        self.ghost_history = []
        self.guarded_pellet = None
        self.observed_ghost = False
        self.observe_start_time = None
        self.OBSERVE_DURATION = 6.0   # seconds to observe ghost patrol before first wheel command

        # Navigation state
        self.planned = False
        self.order = None
        self.segments = []
        self.seg_idx = 0
        self.seg_start_dist = 0.0
        self.state = "OBSERVE"   # "OBSERVE", "TURN", "DRIVE", "DONE"
        self.finished = False

    def on_pellets(self, msg):
        """Called whenever the remaining-pellet list arrives or changes.

        msg is {"pellets": [[row, col], ...]}.
        """
        self.pellets = [tuple(c) for c in msg.get("pellets", [])]
        self.have_pellets = True
        print(f"pellets remaining: {self.pellets}")

    def plan_route(self):
        if not self.pellets:
            return
        # Identify guarded pellet from ghost centroid
        if self.ghost_history:
            gx = sum(p[0] for p in self.ghost_history) / len(self.ghost_history)
            gy = sum(p[1] for p in self.ghost_history) / len(self.ghost_history)
            self.guarded_pellet = min(
                self.pellets,
                key=lambda p: math.hypot(cell_xy(*p)[0] - gx, cell_xy(*p)[1] - gy)
            )
            print(f"Guarded pellet detected at: {self.guarded_pellet}")

        res = best_order(self.maze, self.pellets)
        if res is None:
            print("ERROR: No path found!")
            return
        total_cells, full_path, order = res
        self.order = order
        self.segments = path_to_segments(full_path)
        self.seg_idx = 0
        self.seg_start_dist = 0.0
        self.planned = True
        print(f"Planned order: {order}, total cells: {total_cells}, segments: {len(self.segments)}")
        for idx, seg in enumerate(self.segments):
            print(f"  seg {idx}: heading {seg['heading']} from {seg['start_cell']} to {seg['end_cell']} "
                  f"exit={seg['is_exit']}")

    def is_ghost_dangerous(self):
        """Check if ghost is threatening our robot or our upcoming move."""
        if self.ghost is None:
            return False
        gx, gy = self.ghost["x"], self.ghost["y"]
        d_bot = math.hypot(gx - self.x, gy - self.y)

        # Catch radius is 0.11 m; stop if ghost is near
        if d_bot < 0.22:
            return True

        gr, gc = self.ghost["row"], self.ghost["col"]
        br = min(max(int(round((14 * CELL - self.y) / CELL)), 0), GRID - 1)
        bc = min(max(int(round(self.x / CELL)), 0), GRID - 1)

        # Same cell or immediate connected cell without a wall
        if (gr, gc) == (br, bc) and d_bot < 0.40:
            return True

        if d_bot < 0.40:
            for h, nxt in self.maze.neighbours((br, bc)):
                if nxt == (gr, gc):
                    return True

        # Guarded pellet approach: wait if ghost is near the pellet
        if self.guarded_pellet is not None and self.guarded_pellet in self.pellets:
            px, py = cell_xy(*self.guarded_pellet)
            d_bot_pel = math.hypot(self.x - px, self.y - py)
            d_ghost_pel = math.hypot(gx - px, gy - py)
            if d_bot_pel < 0.50 and d_ghost_pel < 0.38:
                return True

        return False

    def decide(self, s):
        """One sensor frame in, one wheel command out.

        `s` is the decoded pacbot/sensors payload. Return (left, right) in
        rad/s.
        """
        self.elapsed += s["dt"]
        dt = s["dt"]

        # Track ghost history during observation phase
        if self.ghost is not None and not self.observed_ghost:
            self.ghost_history.append((self.ghost["x"], self.ghost["y"]))
            if self.observe_start_time is None:
                self.observe_start_time = time.time()

        # Update Odometry
        tl, tr = s["ticks_l"], s["ticks_r"]
        if self.prev_ticks is None or dt <= 0:
            self.prev_ticks = (tl, tr)
            return 0.0, 0.0

        dl = tl - self.prev_ticks[0]
        dr = tr - self.prev_ticks[1]
        self.prev_ticks = (tl, tr)

        dist = WHEEL_RADIUS * ((dl + dr) / 2.0) * TICK_RAD
        self.total_travel += dist

        wz = s["gyro"][2]
        self.th = wrap(self.th + wz * dt)
        self.x += dist * math.cos(self.th)
        self.y += dist * math.sin(self.th)

        # Nothing to do until we know where the pellets are.
        if not self.have_pellets:
            return 0.0, 0.0

        # Phase 1: OBSERVE ghost before moving
        if self.state == "OBSERVE":
            if (self.observe_start_time is not None and
                    time.time() - self.observe_start_time >= self.OBSERVE_DURATION):
                self.observed_ghost = True
                self.plan_route()
                self.state = "TURN"
                self.seg_start_dist = self.total_travel
            return 0.0, 0.0

        if self.finished or self.seg_idx >= len(self.segments):
            return 0.0, 0.0

        # Ghost safety check: stop wheels if ghost is threatening
        if self.is_ghost_dangerous():
            return 0.0, 0.0

        curr_seg = self.segments[self.seg_idx]
        h = curr_seg["heading"]
        target_angle = curr_seg["target_angle"]
        is_exit = curr_seg["is_exit"]

        # Phase 2: TURN in place
        if self.state == "TURN":
            head_err = wrap(target_angle - self.th)
            if abs(head_err) < 0.025 and abs(wz) < 0.15:
                self.state = "DRIVE"
                self.seg_start_dist = self.total_travel
                return 0.0, 0.0
            else:
                K_TURN = 4.0
                TURN_SPEED = 2.5
                MIN_TURN = 0.8
                w = max(-TURN_SPEED, min(TURN_SPEED, K_TURN * head_err))
                if abs(w) < MIN_TURN:
                    w = math.copysign(MIN_TURN, w)
                w_wheel = w * HALF_TRACK / WHEEL_RADIUS
                return -w_wheel, w_wheel

        # Phase 3: DRIVE straight along corridor
        if self.state == "DRIVE":
            head_err = wrap(target_angle - self.th)

            # Lateral error in robot body frame: positive means steer left
            fl = s["fl"]
            fr = s["fr"]
            front_dist = min(s["sl"], s["sr"])

            SIDE_OPEN = 0.160
            TARGET_SIDE = 0.100

            has_l = fl < SIDE_OPEN
            has_r = fr < SIDE_OPEN
            if has_l and has_r:
                lat_err = (fl - fr) / 2.0
            elif has_l:
                lat_err = fl - TARGET_SIDE
            elif has_r:
                lat_err = TARGET_SIDE - fr
            else:
                lat_err = 0.0

            KP_HEAD = 4.0
            KP_LAT = 12.0
            MAX_CORR = 2.5
            corr = max(-MAX_CORR, min(MAX_CORR, KP_HEAD * head_err + KP_LAT * lat_err))

            if is_exit:
                if self.x >= 3.25:
                    self.finished = True
                    return 0.0, 0.0
                speed = 12.0
            else:
                # Calculate required travel distance for this segment
                c_start = curr_seg["start_cell"]
                c_end = curr_seg["end_cell"]
                d_cells = abs(c_end[0] - c_start[0]) + abs(c_end[1] - c_start[1])

                # If this is the initial move from spawn (-0.15, 0.0) into cell (14, 0)
                if self.seg_idx == 0 and c_start == (14, 0):
                    target_dist = 0.15 + d_cells * CELL
                else:
                    target_dist = d_cells * CELL

                progress = self.total_travel - self.seg_start_dist
                dist_rem = target_dist - progress

                # Front wall stop safeguard
                FRONT_STOP = 0.122
                FRONT_SLOW = 0.350
                has_front_wall = not self.maze.can_move(c_end, h)
                reached_front = has_front_wall and (front_dist <= FRONT_STOP)

                if dist_rem <= 0.002 or reached_front:
                    self.seg_idx += 1
                    if self.seg_idx >= len(self.segments):
                        self.finished = True
                        return 0.0, 0.0
                    next_seg = self.segments[self.seg_idx]
                    if next_seg["heading"] != h:
                        self.state = "TURN"
                    else:
                        self.seg_start_dist = self.total_travel
                    return 0.0, 0.0

                CRUISE_SPEED = 14.0
                SLOW_SPEED = 3.0
                SLOW_ZONE = 0.18

                if has_front_wall and front_dist < FRONT_SLOW:
                    frac = max(0.0, min(1.0, (front_dist - FRONT_STOP) / (FRONT_SLOW - FRONT_STOP)))
                    speed = SLOW_SPEED + (CRUISE_SPEED - SLOW_SPEED) * frac
                elif dist_rem < SLOW_ZONE:
                    frac = max(0.0, min(1.0, dist_rem / SLOW_ZONE))
                    speed = SLOW_SPEED + (CRUISE_SPEED - SLOW_SPEED) * frac
                else:
                    speed = CRUISE_SPEED

            left = speed - corr
            right = speed + corr

            if int(self.elapsed * 100) % 15 == 0:
                print(f"[{self.elapsed:5.2f}s] seg {self.seg_idx} ({h}) state={self.state} "
                      f"pos=({self.x:.3f},{self.y:.3f}) th={math.degrees(self.th):+5.1f}° "
                      f"fl={fl:.3f} fr={fr:.3f} f={front_dist:.3f} spd={speed:.1f}")

            return left, right

        return 0.0, 0.0


def main():
    # The official maze, embedded - no file to find, no path to pass.
    # The id printed here must match the one the simulator prints in its
    # banner ("maze official <id> (built in)"). If they ever differ, your
    # planner and the simulator are looking at different walls.
    maze = Maze.official()
    print(f"official maze {maze_2b.MAZE_ID}: {maze.grid}x{maze.grid}, "
          f"spawn row {maze.spawn_row}, exit row {maze.exit_row}")

    controller = Controller(maze)
    client = _mqtt_client()

    def on_message(cli, userdata, msg):
        payload = json.loads(msg.payload.decode())
        if msg.topic == TOPIC_PELLETS:
            controller.on_pellets(payload)
            return
        if msg.topic == TOPIC_GHOST:
            controller.ghost = payload      # {"row":..,"col":..,"x":..,"y":..}
            return
        if msg.topic == TOPIC_RESULT:
            print(f"run over: solved={payload['solved']}, "
                  f"collisions={payload['collisions']}")
            return
        left, right = controller.decide(payload)
        left = max(-WHEEL_LIMIT, min(WHEEL_LIMIT, float(left)))
        right = max(-WHEEL_LIMIT, min(WHEEL_LIMIT, float(right)))
        # Key order matters: the simulator matches a fixed pattern. See the
        # pacbot/wheel_vel notes in the header comment.
        cli.publish(TOPIC_WHEEL_VEL,
                    json.dumps({"left": left, "right": right}))

    client.on_message = on_message
    client.connect(MQTT_HOST, MQTT_PORT)
    client.subscribe(TOPIC_PELLETS)
    client.subscribe(TOPIC_GHOST)
    client.subscribe(TOPIC_RESULT)
    client.subscribe(TOPIC_SENSORS)
    print("connected; waiting for the simulator")
    client.loop_forever()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
